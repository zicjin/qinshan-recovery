#!/bin/sh

#安装expect
function installXvfb(){
	echo "|---------------------[开始安装xvfb离线包]----------------------|"
	rpm -Uvh --force --nodeps xvfb/*.rpm
	echo "|---------------------[安装xvfb离线包结束]----------------------|"
}

installXvfb
